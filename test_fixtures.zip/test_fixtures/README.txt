========================================================================
PDF MD5 Hash Extractor - Test Fixture Set
========================================================================

This package contains test inputs to verify your build of the extractor.
Each top-level folder targets a specific feature.

------------------------------------------------------------------------
CONTENTS
------------------------------------------------------------------------

single_folder/         3 loose PDFs simulating CyberTip reports.
                       Tests the basic case with overlapping hashes.

nested_folders/        PDFs at varying depths. Tests recursive scanning.

mixed_content/         1 PDF + several non-PDF files (.txt, .jpg, .csv,
                       .py). Verifies the tool ignores non-PDF, non-
                       archive files.

edge_cases/            no_hashes.pdf       - PDF with no hashes at all
                       false_positives.pdf - PDF with hash-like strings
                                             in non-whitespace contexts

archives/              single_tip.zip       (1 PDF)
                       multi_tip_bundle.zip (3 PDFs in nested subdirs)
                       evidence.tar.gz      (2 PDFs)
                       backup.tar           (1 PDF)
                       corrupted.zip        (truncated, tests error path)

EXPECTED_RESULTS.txt   Full ground-truth: every hash, per source.

------------------------------------------------------------------------
SUGGESTED TEST RUNS
------------------------------------------------------------------------

TEST 1 - Single folder
    Add single_folder/ as a source. Output:
      CyberTip_001.txt    (5 hashes)
      CyberTip_002.txt    (4 hashes)
      CyberTip_003.txt    (4 hashes)
      _master_hashes.txt  (10 unique - 3 dupes removed within this folder)

TEST 2 - Recursive scanning
    Add nested_folders/ as a source with "Include subfolders" ON.
    Should find all 3 PDFs across case_A/ and case_B/{subdir/,}.
    Re-run with "Include subfolders" OFF - should find NOTHING because
    none of the PDFs are at the top level.

TEST 3 - File-type filtering
    Add mixed_content/ as a source. Output:
      important.txt       (3 hashes)
      _master_hashes.txt  (3 unique)
    The .txt/.jpg/.csv/.py files should not appear in the log at all.

TEST 4 - Edge cases
    Add edge_cases/ as a source. Log should show:
      no_hashes.pdf       -> "no hashes found" (no output file)
      false_positives.pdf -> 1 hash found
    Open false_positives.txt - should contain exactly ONE hash:
      9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a9a
    If your file contains more, the regex isn't requiring whitespace
    boundaries correctly.

TEST 5 - Archives
    Add archives/ as a source. Output:
      single_tip.txt                       (2 hashes)
      multi_tip_bundle__bundle1.txt        (2 hashes)
      multi_tip_bundle__bundle2.txt        (2 hashes)
      multi_tip_bundle__bundle3.txt        (1 hash)
      evidence__evidence1.txt              (1 hash)
      evidence__evidence2.txt              (2 hashes)
      backup.txt                           (2 hashes)
    corrupted.zip should produce an error log entry, not a crash.

TEST 6 - The grand total
    Load all five top-level folders at once. The _master_hashes.txt
    should contain exactly 32 unique hashes. See EXPECTED_RESULTS.txt
    for the complete list.

TEST 7 - Drag-and-drop (if tkinterdnd2 installed)
    From your file manager, drag any combination of these folders or
    archives onto the Sources list. They should appear with [FOLDER]
    or appropriate archive tags ([ZIP], [TAR], etc.).

TEST 8 - 7z and RAR (not pre-built; create yourself if needed)
    These formats can't be reliably built across all platforms, so the
    fixture set doesn't include them. To test:

    7-Zip:    Use 7-Zip to compress a sample PDF (e.g. extract one from
              single_tip.zip) into a .7z file. Drop it onto the tool.
              With py7zr installed, should process normally; without,
              you should see a clear "7z support not installed" message.

    WinRAR:   Same approach with WinRAR. Requires rarfile + the unrar
              system tool installed; otherwise expect a graceful error.

------------------------------------------------------------------------
WHAT YOU'RE VERIFYING
------------------------------------------------------------------------

[ ] Loose PDFs are processed and named after the source PDF
[ ] PDFs inside ZIPs produce <zipname>.txt (single PDF) or
    <zipname>__<pdfname>.txt (multi PDF)
[ ] tar.gz files work and the .tar.gz suffix is stripped cleanly
[ ] Compound extensions (.tar.gz) produce just <name>.txt, not
    <name.tar>.txt
[ ] Plain .tar archives are processed
[ ] Corrupted archives are logged as errors but don't stop processing
[ ] Non-PDF files in scanned folders are silently filtered out
[ ] The whitespace-boundary regex rejects hash-like strings that are
    surrounded by underscores, dots, or other non-whitespace characters
[ ] PDFs with no hashes are logged and no empty output file is written
[ ] Subfolder recursion respects the "Include subfolders" checkbox
[ ] _master_hashes.txt contains the deduplicated union across all sources
[ ] When multiple sources contribute the same hash, the master list
    contains it only once

========================================================================
